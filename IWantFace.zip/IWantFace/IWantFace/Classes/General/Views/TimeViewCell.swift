//
//  TimeViewCell.swift
//  IWantFace
//
//  Created by 张天琦 on 16/3/23.
//  Copyright © 2016年 C2H4. All rights reserved.
//

import UIKit

class TimeViewCell: UICollectionViewCell {

    @IBOutlet weak var timeLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
