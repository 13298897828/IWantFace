//
//  DateViewCell.swift
//  IWantFace
//
//  Created by 张天琦 on 16/3/23.
//  Copyright © 2016年 C2H4. All rights reserved.
//

import UIKit

class DateViewCell: UICollectionViewCell {

    @IBOutlet weak var numLabel: UILabel!
    @IBOutlet weak var imgView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
